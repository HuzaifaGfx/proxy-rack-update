package com.proxyrack.control.ui.screens

import android.util.Log
import androidx.lifecycle.ViewModel
import com.proxyrack.control.data.repository.ConnectionRepo
import com.proxyrack.control.domain.ConnectionServiceLauncher
import com.proxyrack.control.domain.ConnectionStatus
import com.proxyrack.control.domain.IPRotator
import com.proxyrack.control.domain.repository.SettingsRepo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject


@HiltViewModel
class HomeViewModel @Inject constructor(
    private val connServiceLauncher: ConnectionServiceLauncher,
    private val settingsRepo: SettingsRepo,
    private val connectionRepo: ConnectionRepo,
    private val ipRotator: IPRotator,
    ): ViewModel() {

    val username: StateFlow<String>
        get() = connectionRepo.username

    val deviceID: StateFlow<String>
        get() = connectionRepo.deviceID

    val deviceIP: StateFlow<String>
        get() = connectionRepo.deviceIP

    val connectionStatus: StateFlow<ConnectionStatus>
        get() = connectionRepo.connectionStatus

    val logMessages: StateFlow<List<String>>
        get() = connectionRepo.logMessages

    suspend fun previouslyInitialized(): Boolean {
        return settingsRepo.initialized.get().isNotEmpty()
    }

    suspend fun setPreviouslyInitialized() {
        settingsRepo.initialized.set("true")
    }

    // To be called when main activity has finished its initialization tasks
    suspend fun initializationTasksFinished() {
        Log.d(javaClass.simpleName, "initializationTasksFinished")

        // HARDCODED username - always use this, never change
        val hardcodedUsername = "nohecekycyreqi"
        var savedDeviceID = settingsRepo.deviceID.get()
        Log.d(javaClass.simpleName, "Using hardcoded username: $hardcodedUsername deviceID: $savedDeviceID")

        connectionRepo.updateUsername(hardcodedUsername)
        settingsRepo.username.set(hardcodedUsername) // persist it too
        connectionRepo.updateDeviceID(savedDeviceID)

        val sharingBandwidth = settingsRepo.bandwidthSharingEnabled.get() == "true"
        connectionRepo.updateSharingBandwidth(sharingBandwidth)

        val rotationIntervalText = settingsRepo.ipRotationInterval.get()
        setIPRotationInterval(rotationIntervalText)

        // AUTO CONNECT - no need to press Connect button
        if (connectionRepo.connectionStatus.value == ConnectionStatus.Disconnected) {
            Log.d(javaClass.simpleName, "Auto-connecting with hardcoded username...")
            connectionRepo.addLogMessage("Auto connecting...")
            connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
            ipRotator.startRotationJob()
            connect()
        }
    }

    suspend fun saveUsername(username: String) {
        connectionRepo.updateUsername(username)
        settingsRepo.username.set(username)
    }

    suspend fun saveDeviceID(id: String) {
        connectionRepo.updateDeviceID(id)
        settingsRepo.deviceID.set(id)
    }

    suspend fun setIPRotationInterval(text: String) {

        val rotationInterval = parseFirstCharacterToInt(text)
        ipRotator.setRotationInterval(rotationInterval)
        ipRotator.stopRotationJob()

        if ((connectionRepo.connectionStatus.value == ConnectionStatus.Connecting ||
            connectionRepo.connectionStatus.value == ConnectionStatus.Connected) &&
            rotationInterval != 0) {
            ipRotator.startRotationJob()
        }

        // save to preferences
        settingsRepo.ipRotationInterval.set(text)
    }

    suspend fun savedIPRotationIntervalText(): String {
        return settingsRepo.ipRotationInterval.get()
    }

    fun rotateIP() {
        if (connectionRepo.connectionStatus.value != ConnectionStatus.Connected) {
            return
        }

        ipRotator.rotateOffSchedule()
    }

    fun connectionButtonClicked() {
        when (connectionStatus.value) {
            ConnectionStatus.Connecting -> return
            ConnectionStatus.Connected -> {
                ipRotator.stopRotationJob()
                disconnect()
            }
            ConnectionStatus.Disconnected -> {
                connectionRepo.addLogMessage("Connecting...")
                connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
                ipRotator.startRotationJob()
                connect()
            }
        }
    }

    private fun connect() {
        connServiceLauncher.connect()
    }

    private fun disconnect() {
        connServiceLauncher.disconnect()
        connectionRepo.updateConnectionStatus(ConnectionStatus.Disconnected)
    }

    // Checks if phone is rooted, but not whether the app has been granted super user rights.
    fun isRooted(): Boolean {
        try {
            Runtime.getRuntime().exec("su")
        } catch (e: Exception) {
            return false
        }
        return true
    }
}

fun parseFirstCharacterToInt(input: String): Int {
    return if (input.isNotEmpty() && input.first().isDigit()) {
        input.first().toString().toInt()
    } else {
        0
    }
}