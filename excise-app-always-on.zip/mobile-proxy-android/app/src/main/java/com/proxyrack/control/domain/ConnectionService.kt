package com.proxyrack.control.domain

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.util.Log
import androidx.core.app.NotificationCompat
import com.proxyrack.control.BuildConfig
import com.proxyrack.control.MainActivity
import com.proxyrack.control.R
import com.proxyrack.control.data.repository.ConnectionRepo
import com.proxyrack.control.data.repository.IpInfoRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.proxyrack.control.domain.proxy_manager.ProxyManager
import com.proxyrack.control.domain.proxy_manager.ProxyManagerProvider


@AndroidEntryPoint
class ConnectionService : Service() {

    private val TAG = "ConnectionService"

    @Inject
    lateinit var connectionRepo: ConnectionRepo

    @Inject
    lateinit var ipInfoRepo: IpInfoRepository

    @Inject
    lateinit var proxyManagerProvider: ProxyManagerProvider

    private val CHANNEL_ID = "ProxyControlForegroundServiceChannel"

    private val serviceScope = CoroutineScope(Dispatchers.IO)

    private var proxyManager: ProxyManager? = null

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var reconnectJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        setupProxyManager()
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand called")
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("excise")
            .setContentText("Proxy service running (always-on)")
            .setSmallIcon(R.drawable.logo)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(1, notification)

        // need to re-register since it is unregistered when 'onDestroy' is called
        registerOnDisconnectCallback()

        // Always try to connect when service starts
        if (true) { // always connect - username is hardcoded
            connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
            connect()
        } else {
            Log.w(TAG, "No username set, cannot connect yet")
        }

        // START_STICKY = Android will try to restart the service if it is killed
        return START_STICKY
    }

    private fun setupProxyManager() {
        val pid = Process.myPid()
        val androidApiVersion = Build.VERSION.SDK_INT.toString()
        val cpuArch = getCPUArchitecture()

        Log.d(TAG, "androidApiVersion $androidApiVersion")
        Log.d(TAG, "MyApp pid $pid")
        Log.d(TAG, "MyApp cpu arch $cpuArch")

        proxyManager = proxyManagerProvider.new()

        proxyManager!!.registerOnLogEntryCallback { msg ->
            Log.d(TAG, "logEntryCallback msg: $msg")
            connectionRepo.addLogMessage(msg)
        }

        proxyManager!!.registerOnConnectCallback {
            connectionRepo.updateConnectionStatus(ConnectionStatus.Connected)
            Log.d(TAG, "registerOnConnectCallback called")
            reconnectJob?.cancel()

            ipInfoRepo.getIpInfo { ip, error ->
                if (ip != null) {
                    Log.d(TAG, "IP: $ip")
                    connectionRepo.updateDeviceIP(ip)
                } else if (error != null) {
                    Log.d(TAG, error.toString())
                }
            }
        }

        registerOnDisconnectCallback()
    }

    private fun registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Log.d(TAG, "Internet connection available / restored")
                    // Only auto-reconnect if we have credentials and are not already connected
                    if (connectionRepo.connectionStatus.value != ConnectionStatus.Connected &&
                        connectionRepo.connectionStatus.value != ConnectionStatus.Connecting
                    ) {
                        connectionRepo.addLogMessage("Internet restored, auto-reconnecting...")
                        connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
                        connect()
                    }
                }

                override fun onLost(network: Network) {
                    Log.d(TAG, "Internet connection lost")
                }
            }
            connectivityManager?.registerNetworkCallback(request, networkCallback!!)
            Log.d(TAG, "Network callback registered")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register network callback", e)
        }
    }

    private fun registerOnDisconnectCallback() {
        // This callback is only called if we are involuntarily disconnected.
        // In onDestroy we unregister before calling disconnect so manual stop does not trigger it.
        proxyManager?.registerOnDisconnectCallback {
            connectionRepo.updateConnectionStatus(ConnectionStatus.Disconnected)
            Log.d(TAG, "registerOnDisconnectCallback called (involuntary disconnect)")

            // Aggressive auto-reconnect loop while we have a username
            scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = serviceScope.launch {
            var attempt = 0
            while (isActive) {
                val status = connectionRepo.connectionStatus.value
                if (status == ConnectionStatus.Connected || status == ConnectionStatus.Connecting) {
                    // Already connecting or connected (maybe user pressed button)
                    break
                }

                attempt++
                val delayMs = if (attempt <= 3) 3000L else 8000L
                connectionRepo.addLogMessage("Auto-reconnect attempt #$attempt in ${delayMs / 1000}s...")
                delay(delayMs)

                // Re-check after delay
                val current = connectionRepo.connectionStatus.value
                if (current == ConnectionStatus.Connected || current == ConnectionStatus.Connecting) {
                    break
                }

                connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
                connect()
            }
        }
    }

    private fun connect() {
        // Always force fixed username
        val fixedUsername = com.proxyrack.control.ui.screens.HomeViewModel.FIXED_USERNAME
        if (connectionRepo.username.value != fixedUsername) {
            connectionRepo.updateUsername(fixedUsername)
        }
        Log.d(TAG, "sharing bandwidth: ${connectionRepo.sharingBandwidth.value}, username: $fixedUsername")
        serviceScope.launch {
            try {
                proxyManager!!.connect(
                    BuildConfig.SERVER_IP,
                    443,
                    connectionRepo.deviceID.value,
                    fixedUsername,
                    connectionRepo.sharingBandwidth.value
                )
            } catch (e: Exception) {
                Log.d(TAG, "Failed to connect: ${e.message}")
                connectionRepo.updateConnectionStatus(ConnectionStatus.Disconnected)
                // Trigger another reconnect cycle
                scheduleReconnect()
            }
        }
    }

    private fun getCPUArchitecture(): String {
        val supportedABIs = Build.SUPPORTED_ABIS
        if (supportedABIs.isNotEmpty()) {
            val abi = supportedABIs[0]
            return when {
                abi.startsWith("arm64") -> "arm64"
                abi.startsWith("armeabi") -> "armeabi"
                abi.startsWith("x86_64") -> "x86_64"
                abi.startsWith("x86") -> "x86"
                else -> "unknown"
            }
        }
        return "unknown"
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy called")

        reconnectJob?.cancel()
        try {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering network callback", e)
        }

        proxyManager?.unregisterOnDisconnectCallback()
        proxyManager?.disconnect()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "excise Foreground Service Channel",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }
}
