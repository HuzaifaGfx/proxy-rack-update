package com.proxyrack.control.domain

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.proxyrack.control.data.repository.ConnectionRepo
import com.proxyrack.control.domain.repository.SettingsRepo
import com.proxyrack.control.ui.screens.HomeViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    private val TAG = "BootReceiver"

    @Inject
    lateinit var settingsRepo: SettingsRepo

    @Inject
    lateinit var connectionRepo: ConnectionRepo

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        Log.d(TAG, "Received action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON") {

            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val fixedUsername = HomeViewModel.FIXED_USERNAME
                    var deviceId = settingsRepo.deviceID.get()
                    val sharing = settingsRepo.bandwidthSharingEnabled.get() == "true"

                    // Always use fixed username
                    settingsRepo.username.set(fixedUsername)

                    if (deviceId.isBlank()) {
                        // Generate a device ID if none exists yet
                        deviceId = java.util.UUID.randomUUID().toString()
                        settingsRepo.deviceID.set(deviceId)
                    }

                    Log.d(TAG, "Auto-starting Proxy ConnectionService on boot for fixed user: $fixedUsername")
                    connectionRepo.updateUsername(fixedUsername)
                    connectionRepo.updateDeviceID(deviceId)
                    connectionRepo.updateSharingBandwidth(sharing)
                    connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
                    connectionRepo.addLogMessage("Auto-starting after device boot (fixed username)...")

                    val serviceIntent = Intent(context, ConnectionService::class.java)
                    ContextCompat.startForegroundService(context, serviceIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to auto-start ConnectionService on boot", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
