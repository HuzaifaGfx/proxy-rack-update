package com.proxyrack.control.ui.screens

import android.util.Log
import androidx.lifecycle.ViewModel
import com.proxyrack.control.data.repository.ConnectionRepo
import com.proxyrack.control.domain.ConnectionServiceLauncher
import com.proxyrack.control.domain.ConnectionStatus
import com.proxyrack.control.domain.IPRotator
import com.proxyrack.control.domain.repository.SettingsRepo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject


@HiltViewModel
class HomeViewModel @Inject constructor(
    private val connServiceLauncher: ConnectionServiceLauncher,
    private val settingsRepo: SettingsRepo,
    private val connectionRepo: ConnectionRepo,
    private val ipRotator: IPRotator,
    ): ViewModel() {

    companion object {
        // Hardcoded fixed username - never needs to be entered by user
        const val FIXED_USERNAME = "nohecekycyreqi"
    }

    val username: StateFlow<String>
        get() = connectionRepo.username

    val deviceID: StateFlow<String>
        get() = connectionRepo.deviceID

    val deviceIP: StateFlow<String>
        get() = connectionRepo.deviceIP

    val connectionStatus: StateFlow<ConnectionStatus>
        get() = connectionRepo.connectionStatus

    val logMessages: StateFlow<List<String>>
        get() = connectionRepo.logMessages

    suspend fun previouslyInitialized(): Boolean {
        return settingsRepo.initialized.get().isNotEmpty()
    }

    suspend fun setPreviouslyInitialized() {
        settingsRepo.initialized.set("true")
    }

    // To be called when main activity has finished its initialization tasks
    suspend fun initializationTasksFinished() {
        Log.d(javaClass.simpleName, "initializationTasksFinished")

        // Always force the fixed username
        val fixedUsername = FIXED_USERNAME
        var savedDeviceID = settingsRepo.deviceID.get()
        if (savedDeviceID.isBlank()) {
            // deviceID is generated in MainActivity if empty
            savedDeviceID = connectionRepo.deviceID.value
        }

        Log.d(javaClass.simpleName, "Using fixed username: $fixedUsername, deviceID: $savedDeviceID")

        connectionRepo.updateUsername(fixedUsername)
        settingsRepo.username.set(fixedUsername)   // persist it too
        connectionRepo.updateDeviceID(savedDeviceID)

        val sharingBandwidth = settingsRepo.bandwidthSharingEnabled.get() == "true"
        connectionRepo.updateSharingBandwidth(sharingBandwidth)

        val rotationIntervalText = settingsRepo.ipRotationInterval.get()
        setIPRotationInterval(rotationIntervalText)

        // AUTO-CONNECT immediately - no button press needed
        if (connectionRepo.connectionStatus.value == ConnectionStatus.Disconnected) {
            connectionRepo.addLogMessage("Auto-connecting with fixed username: $fixedUsername")
            connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
            ipRotator.startRotationJob()
            connect()
        }
    }

    suspend fun saveUsername(username: String) {
        // Ignore any user input - always keep the fixed username
        connectionRepo.updateUsername(FIXED_USERNAME)
        settingsRepo.username.set(FIXED_USERNAME)
    }

    suspend fun saveDeviceID(id: String) {
        connectionRepo.updateDeviceID(id)
        settingsRepo.deviceID.set(id)
    }

    suspend fun setIPRotationInterval(text: String) {
        val rotationInterval = parseFirstCharacterToInt(text)
        ipRotator.setRotationInterval(rotationInterval)
        ipRotator.stopRotationJob()

        if ((connectionRepo.connectionStatus.value == ConnectionStatus.Connecting ||
            connectionRepo.connectionStatus.value == ConnectionStatus.Connected) &&
            rotationInterval != 0) {
            ipRotator.startRotationJob()
        }
        settingsRepo.ipRotationInterval.set(text)
    }

    suspend fun savedIPRotationIntervalText(): String {
        return settingsRepo.ipRotationInterval.get()
    }

    fun rotateIP() {
        if (connectionRepo.connectionStatus.value != ConnectionStatus.Connected) {
            return
        }
        ipRotator.rotateOffSchedule()
    }

    fun connectionButtonClicked() {
        when (connectionStatus.value) {
            ConnectionStatus.Connecting -> return
            ConnectionStatus.Connected -> {
                // Still allow manual disconnect, but auto-reconnect will bring it back
                ipRotator.stopRotationJob()
                disconnect()
            }
            ConnectionStatus.Disconnected -> {
                connectionRepo.addLogMessage("Connecting...")
                connectionRepo.updateConnectionStatus(ConnectionStatus.Connecting)
                ipRotator.startRotationJob()
                connect()
            }
        }
    }

    private fun connect() {
        connServiceLauncher.connect()
    }

    private fun disconnect() {
        connServiceLauncher.disconnect()
        connectionRepo.updateConnectionStatus(ConnectionStatus.Disconnected)
    }

    fun isRooted(): Boolean {
        try {
            Runtime.getRuntime().exec("su")
        } catch (e: Exception) {
            return false
        }
        return true
    }
}

fun parseFirstCharacterToInt(input: String): Int {
    return if (input.isNotEmpty() && input.first().isDigit()) {
        input.first().toString().toInt()
    } else {
        0
    }
}
